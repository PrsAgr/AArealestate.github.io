<div class="head-title head-title-3 text-<?php echo esc_attr($align); ?> clearfix">
	<<?php echo sanitize_text_field($title_size); ?> class="the-title">
		<span><?php echo sanitize_text_field( $the_title ); ?></span>
	</<?php echo sanitize_text_field($title_size); ?>>
</div>